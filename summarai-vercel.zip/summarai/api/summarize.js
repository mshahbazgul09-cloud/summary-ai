export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { mediaDescription, options } = req.body;

  if (!mediaDescription) {
    return res.status(400).json({ error: "Missing mediaDescription" });
  }

  const optList = [];
  if (options?.transcript) optList.push("TRANSCRIPT");
  if (options?.summary) optList.push("SHORT_SUMMARY");
  if (options?.actions) optList.push("ACTION_ITEMS");
  if (options?.bullets) optList.push("KEY_POINTS");

  if (optList.length === 0) {
    return res.status(400).json({ error: "No output options selected" });
  }

  const prompt = `You are a media analysis AI. The user has provided a media file or URL.

${mediaDescription}

Since you cannot directly play or transcribe audio/video files without a transcription service, please do the following:
1. Acknowledge the media input professionally
2. Generate a SIMULATED but realistic and helpful example output for each requested section, as if you had analyzed the media. Make the content feel like a real meeting/lecture/podcast/video analysis.
3. Make the content rich, detailed, and varied across sections.

Generate the following sections: ${optList.join(", ")}

Respond ONLY with valid JSON in this exact structure:
{
  "transcript": "Full transcript text here (only if TRANSCRIPT requested, else null)",
  "summary": "2-3 paragraph summary here (only if SHORT_SUMMARY requested, else null)",
  "actions": ["action item 1", "action item 2", ...] (only if ACTION_ITEMS requested, else null),
  "bullets": ["key point 1", "key point 2", ...] (only if KEY_POINTS requested, else null)
}

Make each section substantive:
- Transcript: 300-500 words of realistic dialogue/narration
- Summary: 2-3 paragraphs
- Actions: 5-8 specific, actionable items
- Key Points: 6-10 concise bullet points

Do not include any text outside the JSON.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 2000,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      console.error("Anthropic API error:", err);
      return res.status(500).json({ error: "AI service error. Check your API key." });
    }

    const data = await response.json();
    const text = data.content.map((i) => i.text || "").join("");
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    return res.status(200).json(parsed);
  } catch (err) {
    console.error("Handler error:", err);
    return res.status(500).json({ error: err.message || "Internal server error" });
  }
}
